﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool executando = true;
            while (executando)
            {
                Console.WriteLine("Digite o que deseja fazer: \n1- Continuar fazendo divisões \n2- Sair");
                int opcao = int.Parse(Console.ReadLine());
                switch (opcao)
                {
                    case 1:
                        

                        try { 
                            Console.WriteLine("Digite o primeiro número: ");
                        int numerador = int.Parse(Console.ReadLine());
                        Console.WriteLine("Digite o segundo número: ");
                        int denominador = int.Parse(Console.ReadLine());
                        
                            int resultado = numerador / denominador;
                            Console.WriteLine($"Resultado da divisão: {resultado}");

                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Digite um número inteiro!");
                        }
                        catch (DivideByZeroException)
                        {
                            Console.WriteLine("Não é possível dividir por 0!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Erro inesperado: {ex.Message}");
                        }
                        break;
                    case 2:
                        executando = false;
                        Console.WriteLine("Encerrando o programa...");
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        break;

                }
                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
                Console.Clear();
            }
        }
    }
}
